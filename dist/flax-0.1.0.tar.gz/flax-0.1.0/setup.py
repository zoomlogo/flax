# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flax']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['flax = flax.main:run']}

setup_kwargs = {
    'name': 'flax',
    'version': '0.1.0',
    'description': 'flax tacit language',
    'long_description': None,
    'author': 'PyGamer0',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>3.9',
}


setup(**setup_kwargs)
